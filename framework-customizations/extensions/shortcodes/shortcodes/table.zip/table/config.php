<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => __( 'Table', 'getleads' ),
	'description' => __( 'Add a Table', 'getleads' ),
	'tab'         => __( 'Content Elements', 'getleads' ),
	'popup_size'  => 'large'
);